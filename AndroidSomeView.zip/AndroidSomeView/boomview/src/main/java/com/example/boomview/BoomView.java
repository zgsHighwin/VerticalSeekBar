package com.example.boomview;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BoomView extends View {

    private Paint mPaint;
    private Bitmap mBitmap;
    private List<Ball> mBallList = new ArrayList<>();
    private float d = 1;
    private ValueAnimator mValueAnimator;
    private int mWidth;
    private int mHeight;

    class Ball {
        float x;
        float y;
        float r;
        int color;
        float vx;
        float vy;
        float ax;
        float ay;
    }

    public BoomView(final Context context) {
        this(context, null);
    }

    public BoomView(final Context context, @Nullable final AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public BoomView(final Context context, @Nullable final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setStyle(Paint.Style.FILL);
        initPoint(true);
        mValueAnimator = ValueAnimator.ofFloat(0, 1);
        mValueAnimator.setDuration(5000);
        mValueAnimator.setInterpolator(new LinearInterpolator());
        mValueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(final ValueAnimator animation) {
                for (Ball ball : mBallList) {
                    ball.x += ball.vx;
                    ball.y += ball.vy;
                    ball.vx += ball.ax;
                    ball.vy += ball.ay;
                }
                invalidate();
            }
        });
    }

    private void initPoint(boolean random) {
        mBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.test);
        mWidth = mBitmap.getWidth();
        mHeight = mBitmap.getHeight();
        for (int i = 0; i < mBitmap.getWidth(); i++) {
            for (int j = 0; j < mBitmap.getHeight(); j++) {
                Ball ball = new Ball();
                ball.x = i * d + d / 2;
                ball.y = j * d + d / 2;
                ball.r = new Random().nextInt(15) * 1.0f / 2;
                ball.color = mBitmap.getPixel(i, j); //把每个像素点的颜色保存起来
                ball.ax = (float) (Math.pow(-1, Math.ceil(Math.random() * 2)) * Math.random() * 20);
                ball.ay = (float) (Math.pow(-1, Math.ceil(Math.random() * 2)) * Math.random() * 20);
                mBallList.add(ball);
            }
        }
    }

    @Override
    public boolean onTouchEvent(final MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
//            initPoint(true);
            mValueAnimator.start();
        }
        return super.onTouchEvent(event);
    }

    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        int widthPixels = getResources().getDisplayMetrics().widthPixels;
        int heightPixels = getResources().getDisplayMetrics().heightPixels;

        canvas.translate((widthPixels >> 2), (heightPixels >> 2));
        for (Ball ball : mBallList) {
            mPaint.setColor(ball.color);
            canvas.drawCircle(ball.x, ball.y, ball.r, mPaint);
        }
    }
}

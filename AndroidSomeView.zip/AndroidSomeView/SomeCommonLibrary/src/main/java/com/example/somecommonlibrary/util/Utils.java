package com.example.somecommonlibrary.util;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.TypedValue;

import com.example.somecommonlibrary.R;

public class Utils {
    public static float dpToPixel(float dpValue) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dpValue, Resources.getSystem().getDisplayMetrics());
    }

    public static Bitmap getAvatar(Resources res, int width, int resId) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true; //只获取原始图片的宽高信息
        BitmapFactory.decodeResource(res, resId, options);
        options.inJustDecodeBounds = false;
        options.inDensity = options.outWidth;//表示这个bitmap的像素密度
        options.inTargetDensity = width;//表示要被画出来时的目标像素密度
        return BitmapFactory.decodeResource(res, resId, options);

//        输出图片的宽高= 原图片的宽高 / inSampleSize * (inTargetDensity / inDensity)
    }
}
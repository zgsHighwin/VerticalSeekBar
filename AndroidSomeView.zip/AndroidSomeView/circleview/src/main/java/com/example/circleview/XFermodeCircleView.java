package com.example.circleview;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;


public class XFermodeCircleView extends FrameLayout {

    private static final String TAG = "XFermodeCircleView";
    private int mMeasuredWidth;
    private int mMeasuredHeight;
    private int mMinRadius;


    private Paint mPaint;

    private PorterDuffXfermode mPorterDuffXfermode;

    {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPorterDuffXfermode = new PorterDuffXfermode(PorterDuff.Mode.SRC_IN);
        mPaint.setColor(Color.WHITE);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    public XFermodeCircleView(@NonNull final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onSizeChanged(final int w, final int h, final int oldw, final int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        mMeasuredWidth = getMeasuredWidth();
        mMeasuredHeight = getMeasuredHeight();
        mMinRadius = Math.min(mMeasuredWidth >> 1, mMeasuredHeight >> 1);
    }


    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);

    }

    @SuppressLint("NewApi")
    @Override
    protected void dispatchDraw(final Canvas canvas) {
        super.dispatchDraw(canvas);
        int i = canvas.saveLayer(0, 0, mMeasuredWidth, mMeasuredHeight, null);
        canvas.drawCircle(mMeasuredWidth >> 1, mMeasuredHeight >> 1, mMinRadius, mPaint);
        mPaint.setXfermode(mPorterDuffXfermode);
        canvas.drawRect(0, 0, getMeasuredWidth(), getMeasuredHeight(), mPaint);
        canvas.restoreToCount(i);

    }
}
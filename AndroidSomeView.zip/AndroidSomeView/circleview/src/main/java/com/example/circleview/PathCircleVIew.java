package com.example.circleview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class PathCircleVIew extends FrameLayout {

    private int mMeasuredWidth;
    private int mMeasuredHeight;
    private int mRaidus;

    public PathCircleVIew(@NonNull final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
        setWillNotDraw(false);
    }


    @Override
    protected void onSizeChanged(final int w, final int h, final int oldw, final int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        mMeasuredWidth = getMeasuredWidth();
        mMeasuredHeight = getMeasuredHeight();
        mRaidus = Math.min(mMeasuredHeight >> 1, mMeasuredWidth >> 1);
    }

    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        Path path = new Path();
        path.addCircle(mMeasuredWidth >> 1, mMeasuredHeight >> 1, mRaidus, Path.Direction.CW);
        canvas.clipPath(path);
    }
}
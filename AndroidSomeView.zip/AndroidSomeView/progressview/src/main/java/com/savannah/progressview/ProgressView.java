package com.savannah.progressview;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.BounceInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;

import androidx.annotation.FloatRange;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.example.somecommonlibrary.util.Utils;

public class ProgressView extends View {

    private int mWidth;
    private int mHeight;
    private float progress;
    private float progressWidth;
    private ObjectAnimator mAnimator;

    private void setProgress(final float progress) {
        this.progress = progress;
        invalidate();
    }

    public float getProgress() {
        return progress;
    }

    public void setViewProgress(@FloatRange(from = 0.0, to = 1.0) final float progress) {
        if (mAnimator == null) {
            mAnimator = ObjectAnimator.ofFloat(this, "progress", this.progress, progress);
        } else {
            mAnimator.setFloatValues(this.progress, progress);
        }

        mAnimator.setInterpolator(new OvershootInterpolator());
        mAnimator.setDuration(300);
        mAnimator.start();
    }

    public ProgressView(final Context context) {
        super(context);
    }

    public ProgressView(final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
    }

    public ProgressView(final Context context, @Nullable final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    private Paint mProgressPaint;

    private Path mPath;

    private RectF mRectF;

    private Paint mBackgroundPaint;

    private RectF mBackgroundRectF;

    {
        mProgressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mProgressPaint.setColor(Color.BLUE);
        mBackgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mBackgroundPaint.setColor(Color.GRAY);
        mPath = new Path();
        mRectF = new RectF();
        mBackgroundRectF = new RectF();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        int save = canvas.save();
        canvas.clipPath(mPath);
        canvas.drawRect(mRectF, mBackgroundPaint);
        mProgressPaint.setShader(new LinearGradient(0, 0, this.progress * mWidth, mHeight, Color.RED, Color.BLACK, Shader.TileMode.CLAMP));
//        canvas.drawRect(0, 0, this.progress * mWidth, mHeight, mProgressPaint);
        canvas.drawRect(0, 0, this.progress * mWidth, mHeight,mProgressPaint);
//        canvas.drawRoundRect(0, 0, this.progress * mWidth, mHeight, mHeight, mHeight,mProgressPaint);
        canvas.restoreToCount(save);

    }

    @Override
    protected void onSizeChanged(final int w, final int h, final int oldw, final int oldh) {
        mWidth = getMeasuredWidth();
        mHeight = getMeasuredHeight();
        setBorderRectF();
        mPath.addRoundRect(mRectF, mHeight, mHeight, Path.Direction.CCW);
    }

    private void setBorderRectF() {
        mRectF.left = 0;
        mRectF.top = 0;
        mRectF.right = mWidth;
        mRectF.bottom = mHeight;
    }
}
package com.example.androidsomeview.view;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class TagLayout extends ViewGroup {

    List<Rect> viewList = new ArrayList<>();

    public TagLayout(final Context context) {
        super(context);
    }

    public TagLayout(final Context context, final AttributeSet attrs) {
        super(context, attrs);
    }

    public TagLayout(final Context context, final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(final int widthMeasureSpec, final int heightMeasureSpec) {
        int widthUsed = 0;
        int heightUsed = 0;
        int width = 0;
        int height = 0;
        int maxLineHeight = 0;
        int maxWidth = 0;
        int measureWidth = MeasureSpec.getSize(widthMeasureSpec);
        int mode = MeasureSpec.getMode(widthMeasureSpec);
        for (int i = 0; i < getChildCount(); i++) {
            View childView = getChildAt(i);
            measureChildWithMargins(childView, widthMeasureSpec, 0, heightMeasureSpec, 0);
            int childViewMeasuredWidth = childView.getMeasuredWidth();
            int childViewMeasuredHeight = childView.getMeasuredHeight();
            Rect rect;
            if (viewList.size() <= i) {
                rect = new Rect();
                viewList.add(rect);
            } else {
                rect = viewList.get(i);
            }
            if (mode != MeasureSpec.UNSPECIFIED && widthUsed + childViewMeasuredWidth > measureWidth) { //mode 滚动视图,当前是如果是横向的滚动视图的话就不能滚动了，不设置Unspecfied的话
                widthUsed = 0;
                heightUsed = maxLineHeight;
            }
            rect.set(widthUsed, heightUsed, widthUsed + childViewMeasuredWidth, heightUsed + childViewMeasuredHeight);
            widthUsed += childViewMeasuredWidth;
            maxLineHeight = Math.max(maxLineHeight, heightUsed + childViewMeasuredHeight);
            maxWidth = Math.max(maxWidth, widthUsed);
        }
        width = maxWidth;
        height = maxLineHeight;
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onLayout(final boolean changed, final int l, final int t, final int r, final int b) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            Rect rect = viewList.get(i);
            getChildAt(i).layout(rect.left, rect.top, rect.right, rect.bottom);
        }
    }

    @Override
    public LayoutParams generateLayoutParams(final AttributeSet attrs) {
        return new MarginLayoutParams(getContext(), attrs);
    }
}
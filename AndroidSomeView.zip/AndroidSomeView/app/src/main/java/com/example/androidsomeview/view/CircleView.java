package com.example.androidsomeview.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatImageView;

import com.example.somecommonlibrary.util.Utils;

public class CircleView extends AppCompatImageView {
    public static final int RADIUS = (int) Utils.dpToPixel(80);
    public static final int PADDING = (int) Utils.dpToPixel(20);
    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);


    public CircleView(final Context context) {
        super(context);
    }

    public CircleView(final Context context, final AttributeSet attrs) {
        super(context, attrs);
    }

    public CircleView(final Context context, final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(final int widthMeasureSpec, final int heightMeasureSpec) {
        int width = (RADIUS + PADDING) << 1;
        int height = (RADIUS + PADDING) << 1;
        width = resolveSize(width, widthMeasureSpec); //宽作一个尺寸修正
        height = resolveSize(height, heightMeasureSpec); //高作一个尺寸修正
        setMeasuredDimension(width, height);
        //resolveSize代码等同于
//        int mode = MeasureSpec.getMode(widthMeasureSpec);
//        int specWidth = MeasureSpec.getSize(widthMeasureSpec);
//        switch (mode) {
//            case MeasureSpec.EXACTLY:
//                width = specWidth;
//                break;
//            case MeasureSpec.AT_MOST:
//                if (width > specWidth) {
//                    width = specWidth;
//                }
//                break;
//            case MeasureSpec.UNSPECIFIED:
//                width = width;
//        }
//        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.RED);
        canvas.drawCircle(PADDING + RADIUS, PADDING + RADIUS, RADIUS, paint);
    }
}
package com.example.simpleditheringview;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import com.example.somecommonlibrary.util.Utils;

import java.util.ArrayList;
import java.util.List;

import static android.animation.ValueAnimator.INFINITE;
import static android.animation.ValueAnimator.REVERSE;

public class SimpleDitherView extends View {

    private int mWidth;
    private int mHeight;
    private int mNum = 2;//数量
    private float mCoefficient = 0.8f;//系数  间距比宽 ，默认1：1
    private float mDitherChildWidth;
    private float maxHeight;
    private float minFloat = Utils.dpToPixel(20);

    public SimpleDitherView(final Context context) {
        super(context);
    }

    public SimpleDitherView(final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
    }

    private Paint mPaint;
    private List<MyRectF> mRectFList = new ArrayList<>();

    {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setColor(Color.parseColor("#C99F99"));
        mPaint.setStyle(Paint.Style.FILL_AND_STROKE);
    }


    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        for (MyRectF rectF : mRectFList) {
            canvas.drawRect(rectF, mPaint);
        }
    }

    public static final int DURATION=500;
    public void setAnimation(MyRectF rectF, final int i) {
        System.out.println("i:" + i);
        float topFrom;
        float topTo;
        float bottomFrom;
        float bottomTo;
        if ((i & 1) == 0) {
            topFrom = rectF.top;
            topTo = (mHeight - minFloat) / 2;
            bottomFrom = rectF.bottom;
            bottomTo = (mHeight + minFloat) / 2;
        } else {
            topFrom = rectF.top;
            topTo = (mHeight - maxHeight) / 2;
            bottomFrom = rectF.bottom;
            bottomTo = mHeight - (maxHeight - maxHeight) / 2;
        }

        ObjectAnimator top = ObjectAnimator.ofFloat(rectF, "top", rectF.top, topTo);
        ObjectAnimator bottom = ObjectAnimator.ofFloat(rectF, "bottom", rectF.bottom, bottomTo);
        top.setDuration(DURATION);
        bottom.setDuration(DURATION);
        top.reverse();
        bottom.reverse();
        top.setRepeatCount(INFINITE);
        bottom.setRepeatCount(INFINITE);
        top.setRepeatMode(REVERSE);
        bottom.setRepeatMode(REVERSE);
    }


    @Override
    protected void onSizeChanged(final int w, final int h, final int oldw, final int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        mWidth = getMeasuredWidth();
        mHeight = getMeasuredHeight();
        mDitherChildWidth = (float) mWidth / (mCoefficient * mNum * 2 + mNum);
        System.out.println("mDitherChildWidth" + mDitherChildWidth);
        maxHeight = mHeight;
        mRectFList.clear();
        for (int i = 0; i < mNum; i++) {
            MyRectF rectF = new MyRectF();
            if (i == 0) {
                rectF.left = mDitherChildWidth * mCoefficient;
                rectF.right = mDitherChildWidth * mCoefficient + mDitherChildWidth;
                rectF.top = (mHeight - maxHeight) / 2;
                rectF.bottom = (mHeight - maxHeight) / 2 + maxHeight;
            } else {
                rectF.left = mDitherChildWidth * mCoefficient * i * 2 + mDitherChildWidth * i + mDitherChildWidth * mCoefficient;
                rectF.right = mDitherChildWidth * mCoefficient * i * 2 + mDitherChildWidth * i + mDitherChildWidth * mCoefficient + mDitherChildWidth;
//                rectF.top = (mHeight - maxHeight) / 2 + (maxHeight - minFloat) * i / (2 * mNum);
//                rectF.bottom = mHeight - ((mHeight - maxHeight) / 2 + (maxHeight - minFloat) * i / (2 * mNum));{
                if ((i & 1) == 1) {
                    rectF.top = (mHeight - minFloat) / 2;
                    rectF.bottom = (mHeight + minFloat) / 2;
                } else {
                    rectF.top = (mHeight - maxHeight) / 2;
                    rectF.bottom = (mHeight - maxHeight) / 2 + maxHeight;
//                rectF.left = mDitherChildWidth * mCoefficient * i * 2 + mDitherChildWidth * i + mDitherChildWidth * mCoefficient;
//                rectF.right = mDitherChildWidth * mCoefficient * i * 2 + mDitherChildWidth * i + mDitherChildWidth * mCoefficient + mDitherChildWidth;
//                rectF.top = (mHeight - maxHeight) / 2 + (maxHeight - minFloat) * i / (2 * mNum);
//                rectF.bottom = mHeight - ((mHeight - maxHeight) / 2 + (maxHeight - minFloat) * i / (2 * mNum));
                }

            }
            mRectFList.add(rectF);
            System.out.println(mRectFList);

        }
        for (int i = 0; i < mRectFList.size(); i++) {
            setAnimation(mRectFList.get(i), i);
        }
    }

    public class MyRectF extends RectF {

        public float getLeft() {
            return left;
        }

        public void setLeft(final float left) {
            this.left = left;
            invalidate();
        }

        public float getTop() {
            return top;
        }

        public void setTop(final float top) {
            this.top = top;
            invalidate();
        }

        public float getRight() {
            return right;
        }

        public void setRight(final float right) {
            this.right = right;
            invalidate();
        }

        public float getBottom() {
            return bottom;
        }

        public void setBottom(final float bottom) {
            this.bottom = bottom;
            invalidate();
        }
    }
}
package com.example.pathview;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.widget.Switch;

public class MySwitch extends Switch {
    public MySwitch(final Context context, final AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getPaddingTop() {
        return super.getPaddingTop();
    }

    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
    }

}
package com.example.pathview.loadfromasset;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Region;

public class ProvinceItem {
    private final Paint mPaint;
    public Path mPath;
    public int color;

    public ProvinceItem(final Path path, final int color) {
        mPath = path;
        this.color = color;
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setColor(color);
    }

    public void draw(final Canvas canvas, final Paint paint, boolean select) {
        if (select) {
            mPaint.clearShadowLayer();
            mPaint.setStrokeWidth(1);
            mPaint.setStyle(Paint.Style.FILL);
            mPaint.setColor(Color.GREEN);
            canvas.drawPath(mPath, mPaint);

            mPaint.setStyle(Paint.Style.STROKE);
            mPaint.setColor(Color.WHITE);
            canvas.drawPath(mPath, mPaint);
        } else {
            mPaint.setStrokeWidth(5);
            mPaint.setStyle(Paint.Style.FILL);
            mPaint.setColor(color);
            canvas.drawPath(mPath, mPaint);
            mPaint.setShadowLayer(8, 0, 0, Color.BLACK);

            mPaint.clearShadowLayer();
            mPaint.setStyle(Paint.Style.STROKE);
            mPaint.setColor(Color.WHITE);
            canvas.drawPath(mPath, mPaint);
        }
    }

    //用来判断是否包含路径
    public boolean isOnTouch(final float x, final float y) {
        RectF rect = new RectF();
        mPath.computeBounds(rect, true);
        Region region = new Region();
        region.setPath(mPath, new Region((int) rect.left, (int) rect.top, (int) rect.right, (int) rect.bottom));
        return region.contains((int) x, (int) y);
    }
}
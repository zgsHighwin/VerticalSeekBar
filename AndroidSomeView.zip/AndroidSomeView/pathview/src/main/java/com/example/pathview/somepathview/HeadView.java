package com.example.pathview.somepathview;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import com.example.pathview.R;
import com.example.somecommonlibrary.util.Utils;

@SuppressLint("NewApi")
public class HeadView extends View {
    public static final int RADIUS = (int) Utils.dpToPixel(100);

    public HeadView(final Context context) {
        super(context);
    }

    public HeadView(final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
    }


    private final Paint mPaint;

    {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    }

    public HeadView(final Context context, @Nullable final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(final Canvas canvas) {
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.test_head01);
        int count = canvas.saveLayer(0, 0, bitmap.getWidth(), bitmap.getHeight(), mPaint);
        canvas.drawCircle(bitmap.getWidth() / 2, bitmap.getHeight() / 2, Utils.dpToPixel(50), mPaint);
        mPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, 0, 0, mPaint);
        mPaint.setXfermode(null);
        canvas.restoreToCount(count);
    }
}

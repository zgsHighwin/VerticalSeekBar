package com.example.pathview.loadfromasset;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.core.graphics.PathParser;

import com.example.pathview.R;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class ChinaMapView extends View {

    private static final String TAG = "ChinaMapView";
    private float mLeft;
    private float mTop;
    private float mRight;
    private float mBottom;
    private int mHeightPixels;
    private int mWidthPixels;
    private float strokeWidth = 100;
    private float mMoveX;
    private float mMoveY;
    private ArrayList<ProvinceItem> mPathList;

    private Paint mPaint;
    private float maxScale;

    {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setStyle(Paint.Style.STROKE);
    }

    private int randomColor() {
        Random random = new Random();
        return Color.argb(255, random.nextInt(255), random.nextInt(255), random.nextInt(255));
    }

    public ChinaMapView(final Context context) {
        super(context);
        init(context);
    }

    public ChinaMapView(final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ChinaMapView(final Context context, @Nullable final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(final Context context) {
        mapThread.start();
    }

    private Thread mapThread = new Thread() {
        @Override
        public void run() {
            loadResource();
        }
    };


    private void loadResource() {
        InputStream inputStream = getResources().openRawResource(R.raw.map_china);
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = null;

        try {
            builder = documentBuilderFactory.newDocumentBuilder();
            Document document = builder.parse(inputStream);
            Element documentElement = document.getDocumentElement();
            NodeList pathNodeList = documentElement.getElementsByTagName("path");
            ArrayList<ProvinceItem> list = new ArrayList<>();
            mLeft = -1;
            mTop = -1;
            mRight = -1;
            mBottom = -1;
            for (int i = 0; i < pathNodeList.getLength(); i++) {
                Element itemElement = (Element) pathNodeList.item(i);
                String pathData = itemElement.getAttribute("android:pathData");
                Path path = PathParser.createPathFromPathData(pathData);
//                path.addCircle(200, 200, 200, Path.Direction.CCW);
                RectF rect = new RectF();
                path.computeBounds(rect, true);
                mLeft = mLeft == -1 ? rect.left : Math.min(mLeft, rect.left);
                mRight = mRight == -1 ? rect.right : Math.max(mRight, rect.right);
                mTop = mTop == -1 ? rect.top : Math.min(mTop, rect.top);
                mBottom = mBottom == -1 ? rect.bottom : Math.max(mBottom, rect.bottom);
                ProvinceItem provinceItem = new ProvinceItem(path, randomColor());
                list.add(provinceItem);
            }
            mWidthPixels = getResources().getDisplayMetrics().widthPixels;
            Log.d(TAG, "mWidthPixels:" + mWidthPixels);
            mHeightPixels = getResources().getDisplayMetrics().heightPixels;
            Log.d(TAG, "mHeightPixels:" + mHeightPixels);
            maxScale = mWidthPixels / (mRight - mLeft);
            Log.d(TAG, "mBottom-mTop:" + (mBottom - mTop));
            mPathList = list;
            postInvalidate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        if (mPathList == null) {
            return;
        }
        canvas.save();
        canvas.scale(maxScale, maxScale);
        for (ProvinceItem provinceItem : mPathList) {
            if (provinceItem == select) {
                provinceItem.draw(canvas, mPaint, true);
            } else {
                provinceItem.draw(canvas, mPaint, false);
            }
        }
    }

    ProvinceItem select;

    @Override
    public boolean onTouchEvent(final MotionEvent event) {
        if (mPathList == null) {
            return false;
        }

        ProvinceItem selectItem = null;
        for (ProvinceItem provinceItem : mPathList) {
            if (provinceItem.isOnTouch(event.getX() / maxScale, event.getY() / maxScale)) {
                selectItem = provinceItem;
            }
        }
        if (selectItem != null) {
            select = selectItem;
        }
        invalidate();
        return true;
    }
}
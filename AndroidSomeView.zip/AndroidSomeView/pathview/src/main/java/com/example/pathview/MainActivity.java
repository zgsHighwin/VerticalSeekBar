package com.example.pathview;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ViewFlipper;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pathview.activity.DrawLineActivity;
import com.example.pathview.activity.LoadFromActivity;
import com.example.pathview.activity.SomePathViewActivity;
import com.example.pathview.activity.TextActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
    }

    public void loadFromVector(View view) {
        startActivity(new Intent(this, LoadFromActivity.class));
    }

    public void somePathView(View view) {
        startActivity(new Intent(this, SomePathViewActivity.class));
    }

    public void drawLine(View view) {
        startActivity(new Intent(this, DrawLineActivity.class));
    }

    public void textActivity(View view) {
        startActivity(new Intent(this, TextActivity.class));
    }
}

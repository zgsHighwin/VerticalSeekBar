package com.example.pathview.somepathview;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import com.example.somecommonlibrary.util.Utils;

@SuppressLint("NewApi")

public class PieView extends View {

    String[] colors = {"#ff0000", "#ff00ff", "#00ffff", "#0000ff"};
    int[] degrees = {60, 120, 70, 110};
    public static final float RADIUS = Utils.dpToPixel(80);
    public static final int PULLED_OUT_INDEX = 2;
    public static final float MOVE_DISTANCE = Utils.dpToPixel(20);

    public PieView(final Context context) {
        super(context);
    }

    public PieView(final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
    }

    public PieView(final Context context, @Nullable final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    private final Paint mPaint;

    {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    }


    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);

        float currentAngle = 0f;
        for (int i = 0; i < 4; i++) {
            int save = canvas.save();

            if (i == PULLED_OUT_INDEX) {
                canvas.translate((float) (MOVE_DISTANCE * Math.cos(Math.toRadians(currentAngle + degrees[i] / 2))),
                        (float) (MOVE_DISTANCE * Math.sin(Math.toRadians(currentAngle + degrees[i] / 2))));
            }
            mPaint.setColor(Color.parseColor(colors[i]));
            canvas.drawArc(getWidth() / 2 - RADIUS, getHeight() / 2 - RADIUS,
                    getWidth() / 2 + RADIUS, getHeight() / 2 + RADIUS, currentAngle, degrees[i], true, mPaint);
            canvas.restoreToCount(save);

            currentAngle += degrees[i];

        }
    }
}

package com.example.pathview.somepathview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class PathDirectionView extends View {

    private Paint mPaint;

    public PathDirectionView(final Context context) {
        this(context, null);
    }

    public PathDirectionView(final Context context, @Nullable final AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public PathDirectionView(final Context context, @Nullable final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    }

    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        Path path = new Path();
        //使用CCW和CW绘制图形时会有交叉的情况，同种时序下可以用FillTyp来实现
        path.addRect(0, 0, 200, 200, Path.Direction.CCW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            path.addRoundRect(100, 100, 300, 300, 100, 100, Path.Direction.CW);
        }
        path.setFillType(Path.FillType.EVEN_ODD);//交叉的模式
        path.addRect(0, 0, 500, 500, Path.Direction.CCW);
        canvas.drawPath(path, mPaint);
    }
}

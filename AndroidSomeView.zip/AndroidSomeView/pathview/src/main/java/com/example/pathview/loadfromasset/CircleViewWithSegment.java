package com.example.pathview.loadfromasset;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.core.graphics.PathParser;

import com.example.pathview.R;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class CircleViewWithSegment extends View {


    private Context mContext;
    private Path mPath;
    private float mAnimatedFraction;
    private float midValue = 0.5f;

    public CircleViewWithSegment(final Context context) {
        super(context);
        init(context);
    }

    public CircleViewWithSegment(final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public CircleViewWithSegment(final Context context, @Nullable final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private Paint mPaint;

    private PathMeasure mPathMeasure;

    {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeWidth(20);
        mPaint.setColor(Color.BLUE);
        mPaint.setStrokeJoin(Paint.Join.ROUND);
        mPaint.setStrokeCap(Paint.Cap.ROUND);
        mPath = new Path();
        mPath.addCircle(300, 300, 200, Path.Direction.CW);
        mPathMeasure = new PathMeasure(mPath, false);
        ValueAnimator valueAnimator = ValueAnimator.ofFloat(0f, 1f);
        valueAnimator.setRepeatCount(ValueAnimator.INFINITE);
        valueAnimator.setRepeatMode(ValueAnimator.REVERSE);
        valueAnimator.setDuration(2000);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {


            @Override
            public void onAnimationUpdate(final ValueAnimator animation) {
                mAnimatedFraction = animation.getAnimatedFraction();
                invalidate();
            }
        });
        valueAnimator.start();
    }

    private void init(final Context context) {
        mContext = context;
    }


    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        float length = mPathMeasure.getLength();
        Path dst = new Path();
//        float start = 0;
//        start = 0.5f * (mAnimatedFraction);
        float start = 0;
        if (mAnimatedFraction <= 0.5) {
            start = 0.5f * mAnimatedFraction;
        } else {
            start = 0.25f + (mAnimatedFraction - 0.5f) * 1.5f;//(1-0.25)/0.5
        }
        mPathMeasure.getSegment(start * length, mAnimatedFraction * length, dst, true);
        canvas.drawPath(dst, mPaint);
//        if (mPathList == null) {
//            return;
//        }
//        canvas.save();
//        canvas.translate(0, disY);
//        canvas.scale(maxScale, maxScale);
//        for (Path path : mPathList) {
//            canvas.drawPath(path, mPaint);
//        }
//        canvas.restore();

    }

    private static final String TAG = "CircleView";


}
package com.example.pathview;

import android.app.Application;

import com.example.pathview.util.UIUtils;

public class MyApplication extends Application {
    private static MyApplication instance;

    @Override
    public void onCreate() {
        super.onCreate();
        UIUtils.getInstance(this);
        instance = this;
    }

    public static MyApplication getInstance() {
        return instance;
    }
}
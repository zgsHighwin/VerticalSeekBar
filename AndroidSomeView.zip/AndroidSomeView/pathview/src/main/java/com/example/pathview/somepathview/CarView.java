package com.example.pathview.somepathview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.example.pathview.R;


@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
public class CarView extends View {

    private PathMeasure mPathMeasure;
    private Path mPath;

    private Paint mPaint;
    private Bitmap mBitmap;
    private float carDistance;

    private Matrix mMatrix;

    {
        mBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.car);
        mPath = new Path();
        mPath.addCircle(0, 0, 200, Path.Direction.CCW);

        mPathMeasure = new PathMeasure(mPath, true);
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeWidth(20);
        mPaint.setColor(Color.BLACK);
        mMatrix = new Matrix();
    }

    public CarView(final Context context) {
        super(context);
    }

    public CarView(final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
    }

    public CarView(final Context context, @Nullable final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        mMatrix.reset();
        canvas.translate(getWidth() >> 1, getHeight() >> 1);

        carDistance += 0.01;
        if (carDistance >= 1) {
            carDistance = 0;
        }
        float[] pos = new float[2];
        float[] tan = new float[2];
        float distance = mPathMeasure.getLength() * carDistance;
        mPathMeasure.getPosTan(distance, pos, tan); //pos表示坐标，tan表示该点的正切值
        //tan[0] cos tan[1] =sin
        float degree = (float) (Math.atan2(tan[1], tan[0]) * 180 / Math.PI);
        mMatrix.postRotate(degree, mBitmap.getWidth() >> 1, mBitmap.getHeight() >> 1);
        mMatrix.postTranslate(pos[0] - (mBitmap.getWidth() >> 1), pos[1] - (mBitmap.getHeight() >> 1));
        canvas.drawPath(mPath,mPaint);
        canvas.drawBitmap(mBitmap,mMatrix,new Paint());
        invalidate();
    }
}
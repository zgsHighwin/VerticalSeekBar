package com.example.pathview.loadfromasset;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.graphics.PathParser;

import com.example.pathview.R;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class PaySuccessView extends View {

    private static final String TAG = "PaySuccessView";
    public static final int CIRCLE = 2297;
    public static final int CHECK = 2298;
    private Path circlePath;
    private Path checkPath;
    private PathMeasure circlePathMeasure;
    private PathMeasure checkPathMeasure;
    private float mAnimatedFraction;

    public PaySuccessView(final Context context) {
        super(context);
        init(context);
    }

    public PaySuccessView(final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public PaySuccessView(final Context context, @Nullable final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);

    }

    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(@NonNull final Message msg) {
            super.handleMessage(msg);

            ValueAnimator valueAnimator = ValueAnimator.ofFloat(0, 1f);
            valueAnimator.setDuration(2000);
            valueAnimator.setRepeatMode(ValueAnimator.RESTART);
            valueAnimator.setRepeatCount(ValueAnimator.INFINITE);
            valueAnimator.start();
            valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(final ValueAnimator animation) {
                    mAnimatedFraction = animation.getAnimatedFraction();
                    Log.d(TAG, "mAnimatedFraction:" + mAnimatedFraction);
                    invalidate();
                }
            });
        }

    };

    private Path mCirclePathDst;
    private Path mCheckPathDst;

    private Paint mPaint;

    {
        mCirclePathDst = new Path();
        mCheckPathDst = new Path();
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setStrokeCap(Paint.Cap.ROUND);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeWidth(20);

        checkPathMeasure = new PathMeasure();
        circlePathMeasure = new PathMeasure();
    }

    private void init(final Context context) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                InputStream inputStream = context.getResources().openRawResource(R.raw.pay_success);
                DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();

                DocumentBuilder documentBuilder = null;
                try {
                    documentBuilder = documentBuilderFactory.newDocumentBuilder();
                    Document document = documentBuilder.parse(inputStream);
                    Element documentElement = document.getDocumentElement();
                    NodeList nodeList = documentElement.getElementsByTagName("path");
                    int length = nodeList.getLength();
                    Log.d("PaySuccessView", "length:" + length);
                    for (int i = 0; i < length; i++) {
                        Element itemElement = (Element) nodeList.item(i);
                        String idValue = itemElement.getAttribute("p-id");
                        String pathData = itemElement.getAttribute("d");
                        if (CIRCLE == Integer.parseInt(idValue)) {
                            circlePath = PathParser.createPathFromPathData(pathData);
                            circlePathMeasure.setPath(circlePath, false);
                        } else {
                            checkPath = PathParser.createPathFromPathData(pathData);
                            checkPathMeasure.setPath(checkPath, false);
                        }
                    }

                    mHandler.sendEmptyMessage(0);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        if (circlePath == null && checkPath == null) {
            return;
        }

        mCirclePathDst.reset();
        mCheckPathDst.reset();
        float circleLength = circlePathMeasure.getLength();
        float checkLength = checkPathMeasure.getLength();
        Log.i(TAG, "className:PaySuccessView methodName:onDraw\tcircleLength:" + circleLength + "\tcheckLength:" + checkLength + " value:" + mAnimatedFraction);
        circlePathMeasure.getSegment(0, circleLength * mAnimatedFraction, mCirclePathDst, true);
        checkPathMeasure.getSegment(0, checkLength * mAnimatedFraction, mCheckPathDst, true);

        canvas.drawPath(mCirclePathDst, mPaint);
        canvas.drawPath(mCheckPathDst, mPaint);
    }


}
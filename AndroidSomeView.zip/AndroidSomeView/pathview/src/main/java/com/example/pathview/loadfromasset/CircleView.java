package com.example.pathview.loadfromasset;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.core.graphics.PathParser;

import com.example.pathview.R;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class CircleView extends View implements GestureDetector.OnGestureListener {
    private Context mContext;
    private List<Path> mPathList;
    private float maxScale = 1.0f;
    private GestureDetector mGestureDetector;
    private float mLeft;
    private float mTop;
    private float mRight;
    private float mBottom;
    private int mHeightPixels;
    private int mWidthPixels;
    private float strokeWidth = 100;
    private float mMoveX;
    private float mMoveY;

    public CircleView(final Context context) {
        super(context);
        init(context);
    }

    public CircleView(final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public CircleView(final Context context, @Nullable final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private Paint mPaint;

    {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setColor(Color.YELLOW);
        mPaint.setStyle(Paint.Style.FILL);
    }

    private void init(final Context context) {

        mContext = context;
        mGestureDetector = new GestureDetector(context, this);
        loadVectorThread.start();
    }

    public Thread loadVectorThread = new Thread() {
        @Override
        public void run() {
            loadResource();
        }
    };

    float lastX;
    float lastY;
    float lastDisY;
    float total;

    @Override
    public boolean onTouchEvent(final MotionEvent event) {

//        int actionMasked = event.getActionMasked();
//        switch (actionMasked) {
//            case MotionEvent.ACTION_DOWN:
//                lastY = event.getY();
//                break;
//            case MotionEvent.ACTION_MOVE:
//                mMoveX = event.getX();
//                mMoveY = event.getY();
//                Log.d(TAG, "moveX:" + mMoveX);
//                Log.d(TAG, "moveY:" + mMoveY);
//                disY = lastDisY + mMoveY - lastY;
//                Log.d(TAG, "disY:" + disY);
//                invalidate();
//                break;
//            case MotionEvent.ACTION_UP:
//                lastDisY = disY;
//                break;
//        }
//
//        return true;
        return mGestureDetector.onTouchEvent(event);

    }

    private void loadResource() {
        InputStream inputStream = getResources().openRawResource(R.raw.ic_circle_border);
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = null;

        try {
            builder = documentBuilderFactory.newDocumentBuilder();
            Document document = builder.parse(inputStream);
            Element documentElement = document.getDocumentElement();
            NodeList pathNodeList = documentElement.getElementsByTagName("path");
            ArrayList<Path> list = new ArrayList<>();
            mLeft = -1;
            mTop = -1;
            mRight = -1;
            mBottom = -1;
            for (int i = 0; i < pathNodeList.getLength(); i++) {
                Element itemElement = (Element) pathNodeList.item(i);
                String pathData = itemElement.getAttribute("android:pathData");
                Path path = PathParser.createPathFromPathData(pathData);
//                path.addCircle(200, 200, 200, Path.Direction.CCW);
                RectF rect = new RectF();
                path.computeBounds(rect, true);
                mLeft = mLeft == -1 ? rect.left : Math.min(mLeft, rect.left);
                mRight = mRight == -1 ? rect.right : Math.max(mRight, rect.right);
                mTop = mTop == -1 ? rect.top : Math.min(mTop, rect.top);
                mBottom = mBottom == -1 ? rect.bottom : Math.max(mBottom, rect.bottom);
                list.add(path);
            }
            mWidthPixels = getResources().getDisplayMetrics().widthPixels;
            Log.d(TAG, "mWidthPixels:" + mWidthPixels);
            mHeightPixels = getResources().getDisplayMetrics().heightPixels;
            Log.d(TAG, "mHeightPixels:" + mHeightPixels);
            maxScale = mWidthPixels / (mRight - mLeft);
            Log.d(TAG, "mBottom-mTop:" + (mBottom - mTop));
            Log.d(TAG, "(mBottom-mTop)*maxScale:" + ((mBottom - mTop) * maxScale));
            mPathList = list;
            postInvalidate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onMeasure(final int widthMeasureSpec, final int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int mode = MeasureSpec.getMode(heightMeasureSpec);
        float height = MeasureSpec.getSize(heightMeasureSpec);
        float width = MeasureSpec.getSize(widthMeasureSpec);
        switch (mode) {
            case MeasureSpec.EXACTLY:
                ViewGroup.LayoutParams layoutParams = getLayoutParams();
                if (layoutParams.width == ViewGroup.LayoutParams.MATCH_PARENT) {
                    height = maxScale * (mBottom - mTop);
                    Log.d(TAG, "height MeasureSpec.EXACTLY:" + height);
                }
                break;
            case MeasureSpec.AT_MOST:
                height = maxScale * (mBottom - mTop);
        }
        setMeasuredDimension((int) width, (int) height);
    }


    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        if (mPathList == null) {
            return;
        }
        canvas.save();
        canvas.translate(0, disY);
        canvas.scale(maxScale, maxScale);
        for (Path path : mPathList) {
            canvas.drawPath(path, mPaint);
        }
        canvas.restore();

    }

    @Override
    public boolean onDown(final MotionEvent e) {
        return true;
    }

    @Override
    public void onShowPress(final MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(final MotionEvent e) {
        return false;
    }

    float disY;
    private static final String TAG = "CircleView";

    @Override
    public boolean onScroll(final MotionEvent e1, final MotionEvent e2, final float distanceX, final float distanceY) {
        disY -= distanceY;
        Log.i(TAG, "onScroll: disY:" + disY + " distanceY:" + distanceY);
        if (disY >= 0) {
            disY = 0;
        }


        float moveDistance = -((mBottom - mTop) * maxScale - (mHeightPixels));//这个位置很有意思，有如果有虚拟导航栏的这段是会多移一点距离
        Log.d(TAG, "moveDistance:" + moveDistance);
        if (disY <= moveDistance) {
            disY = moveDistance;
        }

        if ((mHeightPixels) > (mBottom - mTop) * maxScale) {
            disY = 0;
        }
        invalidate();
        return true;
    }

    @Override
    public void onLongPress(final MotionEvent e) {

    }

    @Override
    public boolean onFling(final MotionEvent e1, final MotionEvent e2, final float velocityX, final float velocityY) {
        return false;
    }

    /**
     * 获取状态栏高度
     *
     * @param context
     * @return
     */
    public static int getStatusBarHeight(Context context) {
        Resources resources = context.getResources();
        int resourceId = resources.getIdentifier("status_bar_height", "dimen", "android");
        int height = resources.getDimensionPixelSize(resourceId);
        Log.d(TAG, "height:getStatusBarHeight:" + height);
        return height;
    }
}
package com.example.pathview.text;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;

public class DrawTextPath extends View {

    private float mAnimatedFraction;

    public DrawTextPath(final Context context) {
        super(context);
    }

    public DrawTextPath(final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
        ValueAnimator valueAnimator = ValueAnimator.ofFloat(0, 1f);
        valueAnimator.setDuration(3000);
        valueAnimator.setRepeatCount(ValueAnimator.INFINITE);
        valueAnimator.setRepeatMode(ValueAnimator.REVERSE);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(final ValueAnimator animation) {
                mAnimatedFraction = animation.getAnimatedFraction();
                Log.d("DrawTextPath", "mAnimatedFraction:" + mAnimatedFraction);
                invalidate();
            }
        });
        valueAnimator.start();
    }

    public DrawTextPath(final Context context, @Nullable final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);

    }


    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        Paint mTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mTextPaint.setStyle(Paint.Style.STROKE);
        mTextPaint.setTextSize(800);
        Path mFontPath = new Path();
        String mText = "12";
        mTextPaint.getTextPath(mText, 0, mText.length(), 0, mTextPaint.getFontSpacing(), mFontPath);
        PathMeasure pathMeasure = new PathMeasure();
        pathMeasure.setPath(mFontPath, false);
        Path path = new Path();


        Log.d("DrawTextPath", "pathMeasure.getLength():" + pathMeasure.getLength());
        pathMeasure.getSegment(0, pathMeasure.getLength() * mAnimatedFraction, path, true);
        canvas.drawPath(path, mTextPaint);

    }
    /**
     *4.nextContour
     * 我们知道 Path 可以由多条曲线构成，但不论是 getLength , getSegment 或者是其它方法，都只会在其中第一条线段上运行，而这个 nextContour 就是用于跳转到下一条曲线到方法，如果跳转成功，则返回 true， 如果跳转失败，则返回 false。
     *
     * 如下，我们创建了一个 Path 并使其中包含了两个闭合的曲线，内部的边长是200，外面的边长是400，现在我们使用 PathMeasure 分别测量两条曲线的总长度。
     PathMeasure measure = new PathMeasure(path, false);     // 将Path与PathMeasure关联

     float len1 = measure.getLength();                       // 获得第一条路径的长度

     measure.nextContour();                                  // 跳转到下一条路径

     float len2 = measure.getLength();                       // 获得第二条路径的长度

     Log.i("LEN","len1="+len1);                              // 输出两条路径的长度
     Log.i("LEN","len2="+len2);
     */
}
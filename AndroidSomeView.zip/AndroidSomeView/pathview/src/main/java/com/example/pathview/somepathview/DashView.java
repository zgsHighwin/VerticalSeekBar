package com.example.pathview.somepathview;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathDashPathEffect;
import android.graphics.PathMeasure;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;

import com.example.somecommonlibrary.util.Utils;

@SuppressLint("NewApi")
public class DashView extends View {
    public static final float RADIUS = Utils.dpToPixel(100);
    public static final float SWEEP_DEGREE = 120;
    public static final float LINE_DISTANCE = Utils.dpToPixel(90);
    public static final int DASH_COUNT = 20;
    private float mWidth;
    private float mHeight;

    public DashView(final Context context) {
        super(context);
    }

    public DashView(final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
    }

    public DashView(final Context context, @Nullable final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    private Paint mPaint;

    private Path arcDash;
    private PathMeasure mPathMeasure;

    private Path mDashPath;

    private PathDashPathEffect mPathDashPathEffect;

    {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setStyle(Paint.Style.STROKE);
        arcDash = new Path();
        mWidth = getWidth();
        mHeight = getHeight();
        arcDash.addArc(mWidth / 2 - RADIUS,
                mHeight / 2 - RADIUS,
                mWidth / 2 + RADIUS,
                mHeight / 2 + RADIUS,
                90 + SWEEP_DEGREE / 2,
                360 - SWEEP_DEGREE);
        mPathMeasure = new PathMeasure(arcDash, false);
        mDashPath = new Path();
        mDashPath.addRect(0, 0, Utils.dpToPixel(1), Utils.dpToPixel(5), Path.Direction.CW);
        mPathDashPathEffect = new PathDashPathEffect(mDashPath, (mPathMeasure.getLength() - Utils.dpToPixel(1)) / DASH_COUNT, 0, PathDashPathEffect.Style.ROTATE);
    }


    @SuppressLint("NewApi")
    @Override
    protected void onDraw(final Canvas canvas) {
        mWidth = getWidth();
        mHeight = getHeight();
        canvas.drawArc(mWidth / 2 - RADIUS,
                mHeight / 2 - RADIUS,
                mWidth / 2 + RADIUS,
                mHeight / 2 + RADIUS,
                90 + SWEEP_DEGREE / 2,
                360 - SWEEP_DEGREE, false, mPaint
        );
        mPaint.setPathEffect(mPathDashPathEffect);
        canvas.drawArc(mWidth / 2 - RADIUS,
                mHeight / 2 - RADIUS,
                mWidth / 2 + RADIUS,
                mHeight / 2 + RADIUS,
                90 + SWEEP_DEGREE / 2,
                360 - SWEEP_DEGREE, false, mPaint
        );
        mPaint.setPathEffect(null);
        canvas.drawLine(mWidth / 2,
                mHeight / 2,
                (float) (Math.cos(Math.toRadians(getRadiusFormMark(2))) * LINE_DISTANCE + mWidth / 2),
                (float) (Math.sin(Math.toRadians(getRadiusFormMark(2))) * LINE_DISTANCE + mHeight / 2)
                , mPaint);

    }

    float getRadiusFormMark(int mark) {
        float degree = 90 + SWEEP_DEGREE / 2 + (360 - SWEEP_DEGREE) / DASH_COUNT * mark;
        Log.d("DashView", "degree:" + degree);
        return degree;

    }
}

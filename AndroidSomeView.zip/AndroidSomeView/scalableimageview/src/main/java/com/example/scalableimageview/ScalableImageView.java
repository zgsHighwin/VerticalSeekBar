package com.example.scalableimageview;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.OverScroller;

import androidx.annotation.Nullable;
import androidx.core.view.GestureDetectorCompat;

import com.example.somecommonlibrary.util.Utils;

public class ScalableImageView extends View implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener, Runnable {
    private static final String TAG = "ScalableImageView";
    public static final int IMAGE_WIDTH = (int) Utils.dpToPixel(100);
    public static final float MAX_OVER_SIZE_FACOTR = 5f;
    private final Bitmap bitmap;
    private final Paint mPaint;
    private final GestureDetector mGestureDetector;
    private final OverScroller mOverScroller;
    private final ScaleGestureDetector mScaleGestureDetector;
    private boolean isBig;//是否是处在放大状态

    private float originalOffsetX;
    private float originalOffsetY;
    private float offsetX;
    private float offsetY;
    private float scale;
    private float bigScale;
    private float smallScale;
    //    private float scaleFraction;//值从0到1
    private float currentScale;
    private ObjectAnimator mScaleAnimator;

    public float getCurrentScale() {
        return currentScale;
    }

    public void setCurrentScale(final float currentScale) {
        this.currentScale = currentScale;
        invalidate();
    }

    public ScalableImageView(final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
        bitmap = Utils.getAvatar(getResources(), IMAGE_WIDTH, R.drawable.temp01);
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mGestureDetector = new GestureDetector(getContext(), this);
        mScaleGestureDetector = new ScaleGestureDetector(getContext(), new MyOnScaleGestureListener());
        mOverScroller = new OverScroller(getContext());
    }

    private class MyOnScaleGestureListener implements ScaleGestureDetector.OnScaleGestureListener {

        private float initialScale;

        @Override
        public boolean onScale(final ScaleGestureDetector detector) {
            currentScale = initialScale * detector.getScaleFactor();
            invalidate();
            return false;
        }

        @Override
        public boolean onScaleBegin(final ScaleGestureDetector detector) { //scale初始化
            initialScale = currentScale;
            return true;//不返回true则无效
        }

        @Override
        public void onScaleEnd(final ScaleGestureDetector detector) { //scale结束

        }
    }


    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        float scaleFraction = (currentScale - smallScale) / (bigScale - smallScale);
        canvas.translate(offsetX * scaleFraction, offsetY * scaleFraction);
        //绘制图片
        scale = currentScale;
        canvas.scale(scale, scale, getWidth() / 2f, getHeight() / 2f);
        canvas.drawBitmap(bitmap, originalOffsetX, originalOffsetY, mPaint);

    }

    @Override
    protected void onSizeChanged(final int w, final int h, final int oldw, final int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        originalOffsetX = (getMeasuredWidth() - bitmap.getWidth()) / 2f;
        originalOffsetY = (getMeasuredHeight() - bitmap.getHeight()) / 2f;
        if ((bitmap.getWidth() / bitmap.getHeight()) > (getWidth() / getHeight())) {
            smallScale = (float) getMeasuredWidth() / bitmap.getWidth();
            bigScale = (float) getMeasuredHeight() / bitmap.getHeight() * MAX_OVER_SIZE_FACOTR;
        } else {
            smallScale = (float) getMeasuredHeight() / bitmap.getHeight();
            bigScale = (float) getMeasuredWidth() / bitmap.getWidth() * MAX_OVER_SIZE_FACOTR;
        }
        currentScale = smallScale;
    }

    @Override
    public boolean onTouchEvent(final MotionEvent event) {
        boolean result = mScaleGestureDetector.onTouchEvent(event);
        if(!mScaleGestureDetector.isInProgress()){//是否是正在执行手势缩放
            result = mGestureDetector.onTouchEvent(event);
        }
//        return mGestureDetector.onTouchEvent(event);
        return result;
    }

    private ObjectAnimator getScaleObjectAnimator() {
        if (mScaleAnimator == null) {
            mScaleAnimator = ObjectAnimator.ofFloat(this, "currentScale", 0, 1); //这里的0和1 是一定要传，不然报错，实际 是没有用的
        }
        mScaleAnimator.setFloatValues(smallScale, bigScale);
        return mScaleAnimator;
    }

    @Override
    public boolean onDown(final MotionEvent e) {
        return true;
    }

    @Override
    public void onShowPress(final MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(final MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(final MotionEvent e1, final MotionEvent e2, final float distanceX, final float distanceY) {
        Log.i(TAG, "onScroll: ");
        if (isBig) {
            offsetX -= distanceX;
            offsetY -= distanceY;
            verifyOffset();
            invalidate();
        }
        return false;
    }

    private void verifyOffset() {
        offsetX = Math.min(offsetX, (bitmap.getWidth() * bigScale - getWidth()) / 2);
        offsetX = Math.max(offsetX, -(bitmap.getWidth() * bigScale - getWidth()) / 2);
        offsetY = Math.min(offsetY, (bitmap.getHeight() * bigScale - getHeight()) / 2f);
        offsetY = Math.max(offsetY, -(bitmap.getHeight() * bigScale - getHeight()) / 2f);
    }

    @Override
    public void onLongPress(final MotionEvent e) {

    }

    @Override
    public boolean onFling(final MotionEvent e1, final MotionEvent e2, final float velocityX, final float velocityY) {
        if (isBig) {
            mOverScroller.fling((int) offsetX, (int) offsetY, (int) velocityX, (int) velocityY,
                    -(int) (bitmap.getWidth() * bigScale - getWidth() / 2),
                    (int) (bitmap.getWidth() * bigScale - getWidth() / 2),
                    -(int) (bitmap.getHeight() * bigScale - getHeight() / 2),
                    (int) (bitmap.getHeight() * bigScale - getHeight() / 2)
            );
            postOnAnimation(this);
        }

        return false;
    }

    @Override
    public boolean onSingleTapConfirmed(final MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTap(final MotionEvent e) {
        Log.i(TAG, "onDoubleTap: ");
        isBig = !isBig;
        if (isBig) {
            offsetX = (e.getX() - getWidth() / 2f) - (e.getX() - getWidth() / 2f) * bigScale / smallScale;
            offsetY = (e.getY() - getHeight() / 2f) - (e.getY() - getHeight() / 2f) * bigScale / smallScale;
            getScaleObjectAnimator().start();
        } else {
            getScaleObjectAnimator().reverse();
        }
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(final MotionEvent e) {
        return false;
    }

    @Override
    public void run() {
        if (mOverScroller.computeScrollOffset()) {
            offsetX = mOverScroller.getCurrX();
            offsetY = mOverScroller.getCurrY();
            verifyOffset();
            invalidate();
            postOnAnimation(this);
        }
    }
}
package com.example.testview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/**
 * Author:Savannah
 * Description:
 * AndroidSomeView 10/22/20
 */
public class TriangleView extends View {

    private int mWidth;
    private int mHeight;

    public TriangleView(final Context context) {
        super(context);
    }

    public TriangleView(final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
    }

    public TriangleView(final Context context, @Nullable final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    private Paint mPaint;

    private Path mTrianglePath;

    {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        mPaint.setStrokeJoin(Paint.Join.ROUND);
        mTrianglePath = new Path();
    }

    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        mTrianglePath.moveTo(0, mHeight);
        mTrianglePath.lineTo(mWidth, mHeight);
        mTrianglePath.lineTo(mWidth >> 1, 0);
        mTrianglePath.close();
        canvas.drawPath(mTrianglePath, mPaint);
    }

    @Override
    protected void onSizeChanged(final int w, final int h, final int oldw, final int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        mWidth = getWidth();
        mHeight = getHeight();
    }

    public void setColor(int color) {
        mPaint.setColor(color);
        invalidate();
    }
}
package com.example.testview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class LineArrowView extends View {

    public LineArrowView(final Context context) {
        super(context);
    }

    public LineArrowView(final Context context, @Nullable final AttributeSet attrs) {
        super(context, attrs);
    }

    public LineArrowView(final Context context, @Nullable final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    private Paint mPaint;

    {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setColor(Color.RED);
        mPaint.setStrokeWidth(4);
        mPaint.setStrokeJoin(Paint.Join.ROUND);

    }

    float startX;
    float starrY;
    float moveX;
    float moveY;
    float endX;
    float endY;

    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        for (Line line : list) {
            canvas.drawLine(line.startX, line.starrY, line.endX, line.endY, mPaint);
            fillArrow(canvas, line.startX, line.starrY, line.endX, line.endY);
        }
    }

    class Line {
        float startX;
        float starrY;
        float endX;
        float endY;
    }

    private void fillArrow(Canvas canvas, float x0, float y0, float x1, float y1) {

        mPaint.setStyle(Paint.Style.STROKE);

        float deltaX = x1 - x0;
        float deltaY = y1 - y0;
        float frac = (float) 0.05;

        float point_x_1 = x0 + (float) ((1 - frac) * deltaX + frac * deltaY);
        float point_y_1 = y0 + (float) ((1 - frac) * deltaY - frac * deltaX);

        float point_x_2 = x1;
        float point_y_2 = y1;

        float point_x_3 = x0 + (float) ((1 - frac) * deltaX - frac * deltaY);
        float point_y_3 = y0 + (float) ((1 - frac) * deltaY + frac * deltaX);

        Path path = new Path();
        path.setFillType(Path.FillType.EVEN_ODD);

        path.moveTo(point_x_1, point_y_1);
        path.lineTo(point_x_2, point_y_2);
        path.lineTo(point_x_3, point_y_3);
//        path.lineTo(point_x_1, point_y_1);
//        path.lineTo(point_x_1, point_y_1);
//        path.close();

        canvas.drawPath(path, mPaint);
    }

    ArrayList<Line> list = new ArrayList<>();

    @Override
    public boolean onTouchEvent(final MotionEvent event) {
        int actionMasked = event.getActionMasked();
        switch (actionMasked) {
            case MotionEvent.ACTION_DOWN:
                Line line = new Line();
                startX = event.getX();
                starrY = event.getY();
                line.startX = startX;
                line.starrY = starrY;
                list.add(line);
                break;
            case MotionEvent.ACTION_MOVE:
                endX = event.getX();
                endY = event.getY();
                line = list.get(list.size() - 1);
                line.endX = endX;
                line.endY = endY;
                list.add(line);
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                endX = event.getX();
                endY = event.getY();
                line = list.get(list.size() - 1);
                line.endX = endX;
                line.endY = endY;
                list.add(line);
                invalidate();
                break;
        }
        return true;
    }
}